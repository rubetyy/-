-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: 54.180.162.55    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_password` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_nickname` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('cse','$2a$10$rEyRhxsvu1OZdYtb4ebQkulRGGU.OZm1DdG0V0LdZkeZ5yxFeT3VO','홍당무애청자','2021-08-16 15:08:59'),('cse1234','$2a$10$MpPX44Pzr6V9XOub8ThJHO.55f8cAZYevlD.VovZkXjBfsAS9wpKO','반갑습니다','2021-08-18 16:51:51'),('hong1234','$2a$10$iylTzukjOCXMn.QxW13UAOD7bi2tGTYWTCdnb10ueln8di0/ovXYe','앱등이','2021-08-18 16:49:16'),('hsw1234','$2a$10$bCvRh.WldJUb.OPOsJ/nh.CdyCwYvOdZu6GR/uaOUTno2XYT0kv/y','숨쉬는코딩머신','2021-08-18 10:42:11'),('kck1234','$2a$10$s2puD310QQkhex9OcCI9rOl1qf.7Csaqs9/b1wWuTcoaNj9m9RduW','마포구일진','2021-08-16 14:27:16'),('khw1234','$2a$10$CkVs2OAfh/JnewQ.k1diDeNLfEt958ypqk.eLl/F8EOBFfxRG6GkG','더현대서울','2021-08-18 11:09:43'),('kyj1234','$2a$10$kP13OcWoQLkp.E4V3iDR7ujePkLG.S9He3dgkiFH.aP5eibre0oc.','사기안침','2021-08-16 14:30:33'),('kyj2345','$2a$10$m8E.iq4TOPtEhX15xWjpfOkSkcH.SbS6WVS.5wQUb0AnwU1Pne5bK','잼민초불주먹','2021-08-16 15:22:02'),('kyj3456','$2a$10$ZgYxrVkjHvU68hnm4EOtHu7rg.QcO2S8JmkO3r/aZbTxA2zWd6P7C','싸피5기아닙니다','2021-08-18 11:09:27'),('ssafy1234','$2a$10$OpNV3jHAtaUr9b6FuRTc3e9Wh8tftsky8Cn5J4Z3ovn72LcCjw61W','싸피5기','2021-08-19 10:42:58'),('ssafytest','$2a$10$LjrGqcf30KJa3RctXe7ogOcuWU1U0uYUYR7oBhFUoUca71YIz2o1S','테스트용','2021-08-18 16:36:45'),('tason','$2a$10$s/ErvDMDt3mcOldmskP9Z..s2J9G1xsghBSgW8rw0n8iIwqv9sIY.','tason','2021-08-17 13:38:02'),('yyy','$2a$10$2W5xA2lc/4gpAZMqyN81LebKUGux/y6..SJOD8VQx1us9IhnzggWO','홍당당당무','2021-08-16 15:06:13'),('yyy1','$2a$10$tg5qQV4IhNvBD6VHsJpDyu9xeTVzC57tZEaN66X9xt.FOyNXq9C5K','숭구리당당당','2021-08-18 17:26:34'),('yyy2','$2a$10$njDmbvOxxPzAhtbLP5Lz7O2NChVfYPmFcxtcmjOh8wuLLLTeRkOtS','세계서열0위','2021-08-18 17:27:20');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:39:41
