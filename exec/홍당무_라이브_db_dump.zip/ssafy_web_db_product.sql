-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: 54.180.162.55    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_pk` int NOT NULL AUTO_INCREMENT,
  `user_id_seller` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `category_pk` int NOT NULL,
  `product_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_price` int NOT NULL DEFAULT '0',
  `product_view_count` int DEFAULT '0',
  `product_is_live` tinyint(1) DEFAULT '0',
  `product_is_sold` tinyint(1) DEFAULT '0',
  `product_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `live_id` int DEFAULT NULL,
  PRIMARY KEY (`product_pk`),
  KEY `user_id_seller` (`user_id_seller`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`user_id_seller`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'kyj1234',2,'카카오 72% 팜','한개밖에 안먹었는데 써서 못 먹겠음ㅜ\n이거 사실분? 반값에 드립니다 ㅠㅠ ',2000,319,0,1,'2021-08-16 14:40:56',-1),(2,'kck1234',3,'아이폰6 상태 최상급SSSSSS 싸게 팔아요','클럽하우스 하려면 아이폰 필수인거 아시죠?\n소중하게 사용해서 완전 새거에요\n적당한 가격에 올립니다',500000,68,0,1,'2021-08-16 14:45:32',-1),(4,'kyj1234',2,'유기농 사과 팝니다!','시댁에서 많이 보내줘서 2박스 남아서 팔아요~\n잘 익어서 빨갛고 맛있습니다!\n무농약 사과입니다~~\n(가격은 1박스 당 가격입니다)',16900,63,0,1,'2021-08-17 15:20:08',-1),(5,'kyj1234',4,'구찌 의자 팝니다','이거 천만원에 주고 산건데 구찌 의자 팝니다~\n\n침착맨 아닙니다~~\n\n10퍼 할인해서 900만원에 드립니다~',9000000,50,0,1,'2021-08-17 15:24:06',NULL),(6,'kck1234',3,'갤탭팝니다','갤탭 신형 나와서 팝니다\n고장나서 파는거 아닙니다\n진짭니다.\n싸게 드립니다.\n잔 기스는 라이브에서 보여드립니다.',400000,35,0,0,'2021-08-17 15:26:09',NULL),(7,'kck1234',1,'평창 올림픽 모자','평창 모자 팝니다~\n도쿄보단 평창이죠 ㅎㅎ',15000,52,0,1,'2021-08-17 15:31:30',-1),(8,'kck1234',3,'무선 마우스 G프로 검은색/흰색','각각 15000원에 팝니다\n둘 다 별로 안 썼어요!\n안에 건전지도 같이 드립니다',15000,38,0,0,'2021-08-18 10:42:14',NULL),(10,'hsw1234',1,'라코스테 티셔츠 대량 판매해요','라코스테 티셔츠 팔아요\n라운드티 카라티 다있어요\n최상급 상태입니다',120000,48,0,0,'2021-08-18 10:53:11',-1),(11,'kyj2345',3,'아빠 캐논 렌즈 팔아요','엄마가 아빠꺼 팔라고 하셔서 올립니다\n최대한 비싸게 팔라고 하셔서 가격 그대로 팝니다!\n맨날 아빠가 열심히 닦으셔서 깨끗해요~',197000,12,0,0,'2021-08-18 10:54:07',NULL),(12,'hsw1234',2,'엽떡 쿠폰 팔아요','엽떡 할인 쿠폰 팔아요\n카톡 아디 보내주시면 알려드립니다',3000,6,0,0,'2021-08-18 10:55:03',NULL),(13,'hsw1234',3,'아이폰 6 s급','클럽하우스 하려면 아이폰 필수인거 아시죠?\n상태 최상입니다',500000,3,0,0,'2021-08-18 10:56:05',NULL),(14,'hsw1234',4,'진짜 기타','리얼 기타 팔아요\n저녁 8시에 라이브예정입니다\n상태 보고 싶으신 분들은 오세요',100000,12,0,0,'2021-08-18 11:00:21',NULL),(15,'kyj2345',1,'검은색 반팔 셔츠 팔아요','한 번 입었는데 사이즈가 안 맞아서 팝니다\n사이즈 105에요!\n거의 새거입니다 형들이 멋있다고 해줬어요',35000,17,0,1,'2021-08-18 11:02:55',NULL),(16,'khw1234',3,'애플 해드셋','보다 가성비 좋은 해드셋 팔아요',170000,12,0,0,'2021-08-18 11:10:23',NULL),(17,'khw1234',1,'반윤희 스타일 스키니진','패션리더라면 이거 꼭 사세요\n오늘 저녁 8시에 실착 라이브합니다',10000,18,0,0,'2021-08-18 11:11:19',NULL),(18,'kyj3456',4,'텀블러 팜','텀블러 흰색 팝니다\n한번도 안썼습니다',10000,7,0,0,'2021-08-18 11:11:59',NULL),(19,'khw1234',2,'동남아에서 직수입한 망고','처럼 보이는 설빙 망고빙수 기프티콘 팔아요',10000,13,0,0,'2021-08-18 11:12:08',NULL),(20,'khw1234',4,'유명 작가 사진 팔아요','아티스트 kck의 사진전에서 구매했습니다\n갖고있으면 가격 올라요',1000000,4,0,0,'2021-08-18 11:13:12',NULL),(21,'kyj3456',4,'비욘드 폼클렌징','3개 전부 새거입니다.\n각  5000원에 팔아요~',5000,3,0,0,'2021-08-18 11:13:12',NULL),(22,'kyj3456',1,'따뜻한 스웨터 팔아요','겨울에 입으실 스웨터 팝니다\n확대샷 봐도 거의 새거에요~ ',18000,5,0,0,'2021-08-18 11:19:21',NULL),(23,'kyj3456',2,'유기농 블루베리','직접 농사지은 블루베리 입니다\n남아서 팔아요~~\n1KG에 26000에 팔아요 총 3KG 여분 있습니다!',26000,4,0,0,'2021-08-18 11:22:04',NULL),(24,'kck1234',4,'ddd','hj',8888,18,0,1,'2021-08-18 15:34:28',NULL),(25,'ssafytest',1,'나이키 운동화 팝니다','나이키 운동화 빨간색 팝니다! 실물 짱!',30000,7,0,0,'2021-08-18 16:42:36',NULL),(26,'khw1234',3,'아이패드 에어 4 진짜 최상','산지 6개월 됐습니다',500000,97,0,1,'2021-08-18 16:50:57',-1),(27,'kyj1234',2,'유기농사과','유기농 사과',50000,15,0,0,'2021-08-18 19:17:18',-1),(28,'kyj1234',2,'사과','사과',5000,9,0,0,'2021-08-18 19:27:30',NULL),(29,'ssafy1234',4,'샤프팔아요','비싼 샤프 싸게 팝니다!',5000,9,0,1,'2021-08-19 11:13:12',-1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:39:42
